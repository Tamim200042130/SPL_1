# SPL_1


Basically, it is a web based space shooting game. Here we use only HTML, CSS and JS. 
